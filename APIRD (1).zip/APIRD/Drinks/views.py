from django.shortcuts import render
from django.http import HttpResponse
from .models import Drink
from .serializers import DrinkSerializer   
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Create your views here.
# function based view
# class based view

# templates/appname/filename.html
def home(request):
    return render(request, 'Drinks/index.html',context={})

# implementation of api endpoints   
# 
# get method -> get all the drinks


# Request: A user sends a GET request.
# Urls.py -> views.py -> models.py -> serializers.py -> views.py -> Response
# View: The TaskViewSet fetches all tasks from the database.

# Serializer: The TaskSerializer converts those database objects into JSON.
 
# Response: The API returns the JSON data to the user.

# decorators -> @api_view, @permission_classes, @authentication_classes

@api_view(['GET'])
def get_drinks(request):
    if request.method == 'GET':
        drinks = Drink.objects.all() # [obj1,obj2,obj3]
        drinkserializer = DrinkSerializer(drinks,many=True) # [obj1,obj2,obj3] -> [{name: ,price: ,des: ,q:},{},{}]
        return  Response(drinkserializer.data)
        
    
    